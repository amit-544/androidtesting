package com.example.testapplication.ui

import android.app.Application
import dagger.hilt.android.HiltAndroidApp

@HiltAndroidApp
class CatFactsApp : Application()